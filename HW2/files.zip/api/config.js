module.exports = {
  apiKey: '54211d153c324a139e0f6bd120d50545'
}
